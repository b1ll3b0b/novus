# FA+Witch v1.0

Standalone CEM (OptiFine/EMF) animation pack for the vanilla **witch**, isolated
verbatim from **FreshAnimations v1.10.4** (by FreshLX). No assets were authored or
modified — files were pulled directly from the base FA pack.

## Contents

```
assets/minecraft/optifine/cem/witch.jem              # model + part rig
assets/minecraft/optifine/cem/witch_animations.jpm   # root animation model
assets/minecraft/textures/entity/witch.png           # 64x128 FA witch texture
pack.mcmeta                                           # pack_format 15
pack.png                                              # FA base icon
```

`witch.jem` declares `witch_animations.jpm` as its `root` model and renders against
`textures/entity/witch.png` (64x128 — FA's extended layout, not the 64x64 vanilla
sheet). These three files are the complete dependency set; the witch has no
emissive or overlay variants in FA v1.10.4.

## Source

Extracted from `FreshAnimations_v1.10.4.zip` on 2026-05-29. The base pack was
renamed to `FreshAnimations_v1.10.4_PROCESSED.zip` to mark the witch as extracted.

## Notes

- Requires OptiFine **or** EMF (Entity Model Features) + ETF, same as FreshAnimations.
- Built but **not deployed to Paxi**. If deployed alongside the base FA pack, the
  witch CEM paths will overlap — strip `witch.*` from the base pack first to honor
  the no-overlapping-assets rule.

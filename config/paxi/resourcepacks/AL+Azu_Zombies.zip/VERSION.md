# AL+Azu Zombies — version history

## v2.1 — ETF zom_biome warning fix (2026-05-01)

**Bug observed in latest.log (2026-05-01 session):**
```
[ETF]: property number "9. in file "minecraft:optifine/mob/zombie/zom_biome.properties. failed to read.
```

**Root cause:** AL upstream's `zom_biome.properties` defines random_textures
pools 1-8 but contains two orphaned `nbt.9.ArmorItems.0.id=exists:false`
lines (after pools 5 and 8) that reference a pool 9 which doesn't exist.
ETF logs the warning when it tries to parse the orphaned lines.

**Fix:** Stripped both orphaned lines using a CRLF-aware filter (the file
uses Windows-style line endings; an earlier LF-only sed pass missed one of
the two). Functional behavior unchanged — biome-tinted overlays still apply
correctly to all pools 1-8; the warning no longer fires on world load.

This is a pre-existing AL upstream issue we inherited verbatim; v2.0 had
the same warning. v2.1 closes the cosmetic log noise without changing any
spawn / pool / texture behavior.

---

## v2.0 — Clean rebuild from upstream sources (2026-04-30)

Discarded the v1.0–v1.5 architecture and rebuilt from scratch using
Azu's biome-routed CEM selector design as the foundation, with AL
bodies threaded into each pool. The custom area+rarity tagging system
that v1.1 introduced (TAGS.md, MTG/Gaussian curves, manual rarity
tiers) is gone.

Authoritative design record: `MERGE_PLAN.md` in the project's
`zombie_merge/` folder.

### Foundational decisions

- **Pool architecture from Azu** — biome-routed pools (caves / forests
  / badlands / swamps / catch-all) with first-match-wins evaluation.
- **Body shapes from AL** — std (1) / slim (2) / rare (3) / std-crawler
  (4) / slim-crawler (5) / Ollie (6) — added into each Azu pool at
  deliberate weights.
- **Name-tag rules from AL** — 8 Ollie cosplay name patterns (pools
  1–8), verbatim from upstream.
- **Baby pool from AL, biome-aware in this build** — split into 5
  pools: caves/forests/swamps each force 100% crawler (models 4+5);
  catch-all keeps AL upstream's std/slim/crawler-std/crawler-slim mix;
  armored babies use std/slim only.
- **Random_textures pools** — both packs' pools kept verbatim. AL's
  Cold/Snow/Savanna/Warm/Normal subpool design drives variant rotation
  for body shapes 1+2; Azu's per-archetype pools (zombie_detailed/
  guerrero/tridente/vaquero/especial) drive variant rotation for
  models 7-13.
- **zom_biome biome-tinting overlay** preserved from AL.

### Adult pool weights

| Pool | Trigger | Models | Weights | Specialty share |
|---|---|---|---|---|
| 14 | adult, Y ≤ 50 | 1 2 7 9 11 | 2 2 1 1 8 | Minero 57% |
| 15 | adult, forest biomes | 1 2 7 8 | 3 3 2 4 | Guerrero 33% |
| 16 | adult, badlands biomes | 1 2 7 10 | 2 2 1 4 | Vaquero 44% |
| 17 | adult, swamp biomes | 1 2 8 9 13 | 3 2 2 4 10 | Pantano 48% |
| 18 | adult, catch-all | 1 2 3 7 9 11 12 | 24 22 1 12 4 3 1 | AL ~70% / Azu ~30% |

### Bug fixes during the merge

1. **Top-level texture patch on 6 untextured `.jem` files.** AL's
   `zombie.jem`, `zombie4.jem`, `husk.jem`, `drowned.jem`,
   `drowned_outer.jem`, and `head_zombie.jem` shipped without a
   top-level `texture` declaration — they relied on OptiFine's
   "untextured part inherits entity default" convention which
   Entity Model Features (EMF) does not honor. Patched each to
   declare its base texture path explicitly.
2. **Vaquero typo fix.** Azu shipped variant texture files as
   `zombie_valquero2.png` / `zombie_valquero3.png` while the
   `.properties` and `.jem` referenced `zombie_vaquero*.png`. Renamed
   during the merge so all three Vaquero skins (Blanco/Rojo/Verde)
   actually load.
3. **Vaquero VERDE skin added to pool.** Azu's upstream
   `zombie_vaquero.properties` only listed skins 1+2 in the spawn
   pool, despite documenting a third Verde variant in comments and
   shipping the (typo'd) texture file. Pool widened from
   `skins.1=1 2 / weights.1=4 3` to `skins.1=1 2 3 / weights.1=4 3 1`.
   Verde now appears as a ~12.5% rare Vaquero variant.

### Pack metadata

- `pack_format: 15` (1.20.1 native)
- `supported_formats: 6-999`
- Azu's 1.21.2 overlay (one file: an updated `zombie_animations.jpm`)
  is dropped — the base version is what 1.20.1 needs.

### Provenance

Source packs preserved at:
- `Novus/zombie_merge/sources/AL's Zombies Revamped+FA 1.3.zip`
- `Novus/zombie_merge/sources/§bAzu's Enhanced Zombie Variants FA v0.1.zip`

Earlier merges (v1.0-v1.5) are not in scope for this build.

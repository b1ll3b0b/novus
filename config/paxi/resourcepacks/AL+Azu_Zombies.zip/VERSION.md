# AL+Azu Zombies — version history

## v1.0 — Structural fold (current)

First merged build. Folds Azu's Enhanced Zombie Variants pack into the
structure of AL's Zombies Revamped + FA pack. AL is the foundation;
Azu's archetypes are layered on top as additional CEM models.

### What's in here
- **AL's full content** — verbatim. All body-shape variants (standard,
  slim, rare, Ollie cosplay), biome-tinted main pool, biome overlays
  (zom_biome), husk variants, drowned variants, drowned outer layers,
  drowned necromancer, named-character matches (Ollies / Olivia /
  Gawr Gura).
- **Azu's seven archetypes** as additional CEM models — Default
  (zombie_detailed), Guerrero (warrior), Tridente (fisher/king),
  Vaquero (cowboy), Minero (miner), Especial (Creeper Zombie + Dios),
  Pantano (swamp). Each retains its own dedicated geometry and texture
  pool.
- **Azu's `zombie_animations.jpm`** — required by Azu's models for
  Fresh Animations rigging.

### Conflicts resolved
- `assets/minecraft/textures/entity/zombie/zombie.png` — AL wins.
  Azu's was vestigial (none of Azu's CEM models reference the default
  zombie.png path; they all reference their own dedicated textures).
- CEM model index space — Azu's models 1–7 renumbered to 7–13 to fit
  alongside AL's 1–6.
- `cem/zombie.properties` — rewritten as a combined selector. AL's
  name-tag and baby-zombie rules are verbatim. Adult pool now includes
  both AL's body shapes (1, 2, 3 at weights 99/89/2) and Azu's
  archetypes (7–13 at weight 1 each).
- `optifine/emissive.properties` — both packs ship identical content
  (`suffix.emissive=_e`); kept once.

### Bug fixed during merge
- Azu's vaquero variant texture files were misnamed `zombie_valquero2.png`
  / `zombie_valquero3.png` while the `.properties` and `.jem` reference
  `zombie_vaquero.png`. Variants were silently failing to load in
  Azu's pack as shipped. Renamed to match the canonical spelling.

### Known pass-2 work
- Azu's biome routing (Vaquero->badlands, Pantano->swamp, Minero->deep
  caves, Guerrero->forests) is NOT in v1.0. All Azu archetypes spawn
  flat-weighted everywhere. Re-add per-archetype biome bias one at a
  time in pass 2.
- Adult-pool weights are placeholders. Standard zombies get ~50%, slim
  ~45%, Ollie body ~1%, Azu archetypes ~3.5% combined. Tune in pass 2.
- Two pools in `zombie_detailed.properties` (Azu's Default archetype
  texture variation) reference 1.21+ biomes (`pale_garden`, `deep_dark`)
  that don't exist on 1.20.1. Those pools are silently inert. Harmless
  but a candidate to clean up.
